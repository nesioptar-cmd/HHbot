var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js
var NF_ERROR, NF_REQUEST_ID, BlobsInternalError, collectIterator, base64Decode, base64Encode, getEnvironment, getEnvironmentContext, setEnvironmentContext, MissingBlobsEnvironmentError, BASE64_PREFIX, METADATA_HEADER_INTERNAL, METADATA_HEADER_EXTERNAL, METADATA_MAX_SIZE, encodeMetadata, decodeMetadata, getMetadataFromResponse, BlobsConsistencyError, REGION_AUTO, regions, isValidRegion, InvalidBlobsRegionError, DEFAULT_RETRY_DELAY, MIN_RETRY_DELAY, MAX_RETRY, RATE_LIMIT_HEADER, fetchAndRetry, getDelay, sleep, SIGNED_URL_ACCEPT_HEADER, Client, getClientOptions;
var init_chunk_XR3MUBBK = __esm({
  "node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js"() {
    NF_ERROR = "x-nf-error";
    NF_REQUEST_ID = "x-nf-request-id";
    BlobsInternalError = class extends Error {
      constructor(res) {
        let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
        if (res.headers.has(NF_REQUEST_ID)) {
          details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
        }
        super(`Netlify Blobs has generated an internal error (${details})`);
        this.name = "BlobsInternalError";
      }
    };
    collectIterator = async (iterator) => {
      const result = [];
      for await (const item of iterator) {
        result.push(item);
      }
      return result;
    };
    base64Decode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input, "base64").toString();
      }
      return atob(input);
    };
    base64Encode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input).toString("base64");
      }
      return btoa(input);
    };
    getEnvironment = () => {
      const { Deno, Netlify, process: process2 } = globalThis;
      return Netlify?.env ?? Deno?.env ?? {
        delete: (key) => delete process2?.env[key],
        get: (key) => process2?.env[key],
        has: (key) => Boolean(process2?.env[key]),
        set: (key, value) => {
          if (process2?.env) {
            process2.env[key] = value;
          }
        },
        toObject: () => process2?.env ?? {}
      };
    };
    getEnvironmentContext = () => {
      const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
      if (typeof context !== "string" || !context) {
        return {};
      }
      const data = base64Decode(context);
      try {
        return JSON.parse(data);
      } catch {
      }
      return {};
    };
    setEnvironmentContext = (context) => {
      const encodedContext = base64Encode(JSON.stringify(context));
      getEnvironment().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
    };
    MissingBlobsEnvironmentError = class extends Error {
      constructor(requiredProperties) {
        super(
          `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
            ", "
          )}`
        );
        this.name = "MissingBlobsEnvironmentError";
      }
    };
    BASE64_PREFIX = "b64;";
    METADATA_HEADER_INTERNAL = "x-amz-meta-user";
    METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
    METADATA_MAX_SIZE = 2 * 1024;
    encodeMetadata = (metadata) => {
      if (!metadata) {
        return null;
      }
      const encodedObject = base64Encode(JSON.stringify(metadata));
      const payload = `b64;${encodedObject}`;
      if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
        throw new Error("Metadata object exceeds the maximum size");
      }
      return payload;
    };
    decodeMetadata = (header) => {
      if (!header || !header.startsWith(BASE64_PREFIX)) {
        return {};
      }
      const encodedData = header.slice(BASE64_PREFIX.length);
      const decodedData = base64Decode(encodedData);
      const metadata = JSON.parse(decodedData);
      return metadata;
    };
    getMetadataFromResponse = (response) => {
      if (!response.headers) {
        return {};
      }
      const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
      try {
        return decodeMetadata(value);
      } catch {
        throw new Error(
          "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
        );
      }
    };
    BlobsConsistencyError = class extends Error {
      constructor() {
        super(
          `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
        );
        this.name = "BlobsConsistencyError";
      }
    };
    REGION_AUTO = "auto";
    regions = {
      "us-east-1": true,
      "us-east-2": true,
      "eu-central-1": true,
      "ap-southeast-1": true,
      "ap-southeast-2": true
    };
    isValidRegion = (input) => Object.keys(regions).includes(input);
    InvalidBlobsRegionError = class extends Error {
      constructor(region) {
        super(
          `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
        );
        this.name = "InvalidBlobsRegionError";
      }
    };
    DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
    MIN_RETRY_DELAY = 1e3;
    MAX_RETRY = 5;
    RATE_LIMIT_HEADER = "X-RateLimit-Reset";
    fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
      try {
        const res = await fetch2(url, options);
        if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
          const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
          await sleep(delay);
          return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
        }
        return res;
      } catch (error) {
        if (attemptsLeft === 0) {
          throw error;
        }
        const delay = getDelay();
        await sleep(delay);
        return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
      }
    };
    getDelay = (rateLimitReset) => {
      if (!rateLimitReset) {
        return DEFAULT_RETRY_DELAY;
      }
      return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
    };
    sleep = (ms) => new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
    SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
    Client = class {
      constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token: token2, uncachedEdgeURL }) {
        this.apiURL = apiURL;
        this.consistency = consistency ?? "eventual";
        this.edgeURL = edgeURL;
        this.fetch = fetch2 ?? globalThis.fetch;
        this.region = region;
        this.siteID = siteID;
        this.token = token2;
        this.uncachedEdgeURL = uncachedEdgeURL;
        if (!this.fetch) {
          throw new Error(
            "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
          );
        }
      }
      async getFinalRequest({
        consistency: opConsistency,
        key,
        metadata,
        method,
        parameters = {},
        storeName
      }) {
        const encodedMetadata = encodeMetadata(metadata);
        const consistency = opConsistency ?? this.consistency;
        let urlPath = `/${this.siteID}`;
        if (storeName) {
          urlPath += `/${storeName}`;
        }
        if (key) {
          urlPath += `/${key}`;
        }
        if (this.edgeURL) {
          if (consistency === "strong" && !this.uncachedEdgeURL) {
            throw new BlobsConsistencyError();
          }
          const headers = {
            authorization: `Bearer ${this.token}`
          };
          if (encodedMetadata) {
            headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
          }
          if (this.region) {
            urlPath = `/region:${this.region}${urlPath}`;
          }
          const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
          for (const key2 in parameters) {
            url2.searchParams.set(key2, parameters[key2]);
          }
          return {
            headers,
            url: url2.toString()
          };
        }
        const apiHeaders = { authorization: `Bearer ${this.token}` };
        const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
        for (const key2 in parameters) {
          url.searchParams.set(key2, parameters[key2]);
        }
        if (this.region) {
          url.searchParams.set("region", this.region);
        }
        if (storeName === void 0 || key === void 0) {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        if (encodedMetadata) {
          apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
        }
        if (method === "head" || method === "delete") {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        const res = await this.fetch(url.toString(), {
          headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
          method
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        const { url: signedURL } = await res.json();
        const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
        return {
          headers: userHeaders,
          url: signedURL
        };
      }
      async makeRequest({
        body,
        consistency,
        headers: extraHeaders,
        key,
        metadata,
        method,
        parameters,
        storeName
      }) {
        const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
          consistency,
          key,
          metadata,
          method,
          parameters,
          storeName
        });
        const headers = {
          ...baseHeaders,
          ...extraHeaders
        };
        if (method === "put") {
          headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
        }
        const options = {
          body,
          headers,
          method
        };
        if (body instanceof ReadableStream) {
          options.duplex = "half";
        }
        return fetchAndRetry(this.fetch, url, options);
      }
    };
    getClientOptions = (options, contextOverride) => {
      const context = contextOverride ?? getEnvironmentContext();
      const siteID = context.siteID ?? options.siteID;
      const token2 = context.token ?? options.token;
      if (!siteID || !token2) {
        throw new MissingBlobsEnvironmentError(["siteID", "token"]);
      }
      if (options.region !== void 0 && !isValidRegion(options.region)) {
        throw new InvalidBlobsRegionError(options.region);
      }
      const clientOptions = {
        apiURL: context.apiURL ?? options.apiURL,
        consistency: options.consistency,
        edgeURL: context.edgeURL ?? options.edgeURL,
        fetch: options.fetch,
        region: options.region,
        siteID,
        token: token2,
        uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
      };
      return clientOptions;
    };
  }
});

// node_modules/@netlify/blobs/dist/main.js
var main_exports = {};
__export(main_exports, {
  connectLambda: () => connectLambda,
  getDeployStore: () => getDeployStore,
  getStore: () => getStore,
  listStores: () => listStores,
  setEnvironmentContext: () => setEnvironmentContext
});
function listStores(options = {}) {
  const context = getEnvironmentContext();
  const clientOptions = getClientOptions(options, context);
  const client = new Client(clientOptions);
  const iterator = getListIterator(client, SITE_STORE_PREFIX);
  if (options.paginate) {
    return iterator;
  }
  return collectIterator(iterator).then((results) => ({ stores: results.flatMap((page) => page.stores) }));
}
var connectLambda, DEPLOY_STORE_PREFIX, LEGACY_STORE_INTERNAL_PREFIX, SITE_STORE_PREFIX, Store, getDeployStore, getStore, formatListStoreResponse, getListIterator;
var init_main = __esm({
  "node_modules/@netlify/blobs/dist/main.js"() {
    init_chunk_XR3MUBBK();
    connectLambda = (event) => {
      const rawData = base64Decode(event.blobs);
      const data = JSON.parse(rawData);
      const environmentContext = {
        deployID: event.headers["x-nf-deploy-id"],
        edgeURL: data.url,
        siteID: event.headers["x-nf-site-id"],
        token: data.token
      };
      setEnvironmentContext(environmentContext);
    };
    DEPLOY_STORE_PREFIX = "deploy:";
    LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
    SITE_STORE_PREFIX = "site:";
    Store = class _Store {
      constructor(options) {
        this.client = options.client;
        if ("deployID" in options) {
          _Store.validateDeployID(options.deployID);
          let name = DEPLOY_STORE_PREFIX + options.deployID;
          if (options.name) {
            name += `:${options.name}`;
          }
          this.name = name;
        } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
          const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
          _Store.validateStoreName(storeName);
          this.name = storeName;
        } else {
          _Store.validateStoreName(options.name);
          this.name = SITE_STORE_PREFIX + options.name;
        }
      }
      async delete(key) {
        const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
        if (![200, 204, 404].includes(res.status)) {
          throw new BlobsInternalError(res);
        }
      }
      async get(key, options) {
        const { consistency, type } = options ?? {};
        const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        if (type === void 0 || type === "text") {
          return res.text();
        }
        if (type === "arrayBuffer") {
          return res.arrayBuffer();
        }
        if (type === "blob") {
          return res.blob();
        }
        if (type === "json") {
          return res.json();
        }
        if (type === "stream") {
          return res.body;
        }
        throw new BlobsInternalError(res);
      }
      async getMetadata(key, { consistency } = {}) {
        const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const etag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag,
          metadata
        };
        return result;
      }
      async getWithMetadata(key, options) {
        const { consistency, etag: requestETag, type } = options ?? {};
        const headers = requestETag ? { "if-none-match": requestETag } : void 0;
        const res = await this.client.makeRequest({
          consistency,
          headers,
          key,
          method: "get",
          storeName: this.name
        });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const responseETag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag: responseETag,
          metadata
        };
        if (res.status === 304 && requestETag) {
          return { data: null, ...result };
        }
        if (type === void 0 || type === "text") {
          return { data: await res.text(), ...result };
        }
        if (type === "arrayBuffer") {
          return { data: await res.arrayBuffer(), ...result };
        }
        if (type === "blob") {
          return { data: await res.blob(), ...result };
        }
        if (type === "json") {
          return { data: await res.json(), ...result };
        }
        if (type === "stream") {
          return { data: res.body, ...result };
        }
        throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
      }
      list(options = {}) {
        const iterator = this.getListIterator(options);
        if (options.paginate) {
          return iterator;
        }
        return collectIterator(iterator).then(
          (items) => items.reduce(
            (acc, item) => ({
              blobs: [...acc.blobs, ...item.blobs],
              directories: [...acc.directories, ...item.directories]
            }),
            { blobs: [], directories: [] }
          )
        );
      }
      async set(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const res = await this.client.makeRequest({
          body: data,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      async setJSON(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const payload = JSON.stringify(data);
        const headers = {
          "content-type": "application/json"
        };
        const res = await this.client.makeRequest({
          body: payload,
          headers,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      static formatListResultBlob(result) {
        if (!result.key) {
          return null;
        }
        return {
          etag: result.etag,
          key: result.key
        };
      }
      static validateKey(key) {
        if (key === "") {
          throw new Error("Blob key must not be empty.");
        }
        if (key.startsWith("/") || key.startsWith("%2F")) {
          throw new Error("Blob key must not start with forward slash (/).");
        }
        if (new TextEncoder().encode(key).length > 600) {
          throw new Error(
            "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
          );
        }
      }
      static validateDeployID(deployID) {
        if (!/^\w{1,24}$/.test(deployID)) {
          throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
        }
      }
      static validateStoreName(name) {
        if (name.includes("/") || name.includes("%2F")) {
          throw new Error("Store name must not contain forward slashes (/).");
        }
        if (new TextEncoder().encode(name).length > 64) {
          throw new Error(
            "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
          );
        }
      }
      getListIterator(options) {
        const { client, name: storeName } = this;
        const parameters = {};
        if (options?.prefix) {
          parameters.prefix = options.prefix;
        }
        if (options?.directories) {
          parameters.directories = "true";
        }
        return {
          [Symbol.asyncIterator]() {
            let currentCursor = null;
            let done = false;
            return {
              async next() {
                if (done) {
                  return { done: true, value: void 0 };
                }
                const nextParameters = { ...parameters };
                if (currentCursor !== null) {
                  nextParameters.cursor = currentCursor;
                }
                const res = await client.makeRequest({
                  method: "get",
                  parameters: nextParameters,
                  storeName
                });
                let blobs2 = [];
                let directories = [];
                if (![200, 204, 404].includes(res.status)) {
                  throw new BlobsInternalError(res);
                }
                if (res.status === 404) {
                  done = true;
                } else {
                  const page = await res.json();
                  if (page.next_cursor) {
                    currentCursor = page.next_cursor;
                  } else {
                    done = true;
                  }
                  blobs2 = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                  directories = page.directories ?? [];
                }
                return {
                  done: false,
                  value: {
                    blobs: blobs2,
                    directories
                  }
                };
              }
            };
          }
        };
      }
    };
    getDeployStore = (input = {}) => {
      const context = getEnvironmentContext();
      const options = typeof input === "string" ? { name: input } : input;
      const deployID = options.deployID ?? context.deployID;
      if (!deployID) {
        throw new MissingBlobsEnvironmentError(["deployID"]);
      }
      const clientOptions = getClientOptions(options, context);
      if (!clientOptions.region) {
        if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
          if (!context.primaryRegion) {
            throw new Error(
              "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the `getDeployStore` options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
            );
          }
          clientOptions.region = context.primaryRegion;
        } else {
          clientOptions.region = REGION_AUTO;
        }
      }
      const client = new Client(clientOptions);
      return new Store({ client, deployID, name: options.name });
    };
    getStore = (input) => {
      if (typeof input === "string") {
        const clientOptions = getClientOptions({});
        const client = new Client(clientOptions);
        return new Store({ client, name: input });
      }
      if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
        const { name, siteID, token: token2 } = input;
        const clientOptions = getClientOptions(input, { siteID, token: token2 });
        if (!name || !siteID || !token2) {
          throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.name === "string") {
        const { name } = input;
        const clientOptions = getClientOptions(input);
        if (!name) {
          throw new MissingBlobsEnvironmentError(["name"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.deployID === "string") {
        const clientOptions = getClientOptions(input);
        const { deployID } = input;
        if (!deployID) {
          throw new MissingBlobsEnvironmentError(["deployID"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, deployID });
      }
      throw new Error(
        "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
      );
    };
    formatListStoreResponse = (stores) => stores.filter((store) => !store.startsWith(DEPLOY_STORE_PREFIX)).map((store) => store.startsWith(SITE_STORE_PREFIX) ? store.slice(SITE_STORE_PREFIX.length) : store);
    getListIterator = (client, prefix) => {
      const parameters = {
        prefix
      };
      return {
        [Symbol.asyncIterator]() {
          let currentCursor = null;
          let done = false;
          return {
            async next() {
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters
              });
              if (res.status === 404) {
                return { done: true, value: void 0 };
              }
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              return {
                done: false,
                value: {
                  ...page,
                  stores: formatListStoreResponse(page.stores)
                }
              };
            }
          };
        }
      };
    };
  }
});

// netlify/functions/fetch-vacancies.mjs
var fetch_vacancies_exports = {};
__export(fetch_vacancies_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(fetch_vacancies_exports);

// netlify/lib/store.mjs
var import_node_fs = __toESM(require("fs"), 1);
var import_node_path = __toESM(require("path"), 1);
var FILE_DIR = process.env.FILE_STORE_DIR || ".tmp-store";
function fileGet(key, fallback) {
  try {
    const p = import_node_path.default.join(FILE_DIR, key + ".json");
    if (!import_node_fs.default.existsSync(p)) return fallback;
    return JSON.parse(import_node_fs.default.readFileSync(p, "utf8"));
  } catch {
    return fallback;
  }
}
function fileSet(key, val) {
  import_node_fs.default.mkdirSync(FILE_DIR, { recursive: true });
  import_node_fs.default.writeFileSync(import_node_path.default.join(FILE_DIR, key + ".json"), JSON.stringify(val));
}
var blobStore = null;
async function blobs() {
  if (blobStore) return blobStore;
  const { getStore: getStore2 } = await Promise.resolve().then(() => (init_main(), main_exports));
  if (process.env.BLOBS_SITE_ID && process.env.BLOBS_TOKEN) {
    blobStore = getStore2({
      name: "hhbot",
      siteID: process.env.BLOBS_SITE_ID,
      token: process.env.BLOBS_TOKEN
    });
  } else {
    blobStore = getStore2("hhbot");
  }
  return blobStore;
}
async function storeGet(key, fallback = null) {
  if (process.env.STORE === "file") return fileGet(key, fallback);
  try {
    const v = await (await blobs()).get(key, { type: "json" });
    return v ?? fallback;
  } catch (e) {
    console.log("[store] get failed, fallback:", e.message);
    return fallback;
  }
}
async function storeSet(key, val) {
  if (process.env.STORE === "file") return fileSet(key, val);
  await (await blobs()).setJSON(key, val);
}

// netlify/lib/hh.mjs
var SHARDS_URL = "https://hh.ru/shards/vacancy/search";
var OFFICIAL_URL = "https://api.hh.ru/vacancies";
var BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
async function getJson(url, headers = {}) {
  const res = await fetch(url, { headers: { "User-Agent": BROWSER_UA, ...headers } });
  if (!res.ok) throw new Error(`hh.ru HTTP ${res.status}`);
  return res.json();
}
function buildShardsParams(s) {
  const p = new URLSearchParams();
  if (s.text) p.append("text", s.text);
  const sf = (s.search_field || "everywhere").trim();
  if (sf && sf !== "everywhere") p.append("search_field", sf);
  for (const a of s.area || []) p.append("area", String(a));
  for (const x of s.schedule || []) p.append("schedule", x);
  for (const e of s.employment || []) {
    p.append("employment", e);
    p.append("employment_form", e === "full" ? "FULL" : e);
  }
  for (const e of s.experience || []) p.append("experience", e);
  if (s.salary_from) p.append("salary", String(s.salary_from | 0));
  if (s.only_with_salary) p.append("only_with_salary", "true");
  if (s.search_period) p.append("search_period", String(s.search_period | 0));
  p.append("items_on_page", "50");
  return p;
}
function normalizeShards(v) {
  const comp = v.compensation || {};
  const company = v.company || {};
  const reviews = company.employerReviews || {};
  const rating = parseFloat(String(reviews.totalRating || "0").replace(",", ".")) || 0;
  const area = v.area || {};
  const links = v.links || {};
  const formats = [];
  for (const wf of v.workFormats || []) formats.push(...wf.workFormatsElement || []);
  return {
    id: String(v.vacancyId),
    name: v.name || "",
    url: links.desktop || `https://hh.ru/vacancy/${v.vacancyId}`,
    area: area.name || "",
    area_id: String(area["@id"] || ""),
    employer: company.name || company.visibleName || "",
    employer_id: String(company.id || ""),
    rating,
    reviews_count: parseInt(reviews.reviewsCount || 0, 10) || 0,
    salary_from: comp.from ?? null,
    salary_to: comp.to ?? null,
    currency: comp.currencyCode || comp.currency || "",
    schedule: v["@workSchedule"] || "",
    work_formats: formats,
    experience: v.workExperience || "",
    employment: v.employment?.["@type"] || v.employmentForm || "",
    published_at: v.publicationTime?.["$"] || ""
  };
}
async function searchShards(s, maxResults = 50) {
  const base = buildShardsParams(s);
  const out = [];
  let total = null;
  for (let page = 0; page < 40 && out.length < maxResults; page++) {
    const params = new URLSearchParams(base);
    params.append("page", String(page));
    let data;
    try {
      data = await getJson(`${SHARDS_URL}?${params}`);
    } catch (e) {
      console.log("[hh] shards error:", e.message);
      break;
    }
    const r = data.vacancySearchResult || {};
    if (total === null) total = r.totalResults;
    const items = r.vacancies || [];
    if (!items.length) break;
    for (const raw of items) {
      out.push(normalizeShards(raw));
      if (out.length >= maxResults) break;
    }
    const last = r.paging?.lastPage?.page;
    if (last !== void 0 && page >= last) break;
    await sleep2(400);
  }
  return { items: out, total };
}
function normalizeOfficial(v) {
  const emp = v.employer || {};
  const sal = v.salary || {};
  return {
    id: String(v.id),
    name: v.name || "",
    url: v.alternate_url || `https://hh.ru/vacancy/${v.id}`,
    area: v.area?.name || "",
    area_id: String(v.area?.id || ""),
    employer: emp.name || "",
    employer_id: String(emp.id || ""),
    rating: 0,
    reviews_count: 0,
    salary_from: sal.from ?? null,
    salary_to: sal.to ?? null,
    currency: sal.currency || "",
    schedule: v.schedule?.id || "",
    work_formats: v.work_format || [],
    experience: v.experience?.id || "",
    employment: v.employment?.id || "",
    published_at: v.published_at || ""
  };
}
async function searchOfficial(s, token2, userAgent, maxResults = 50) {
  const p = new URLSearchParams();
  if (s.text) p.append("text", s.text);
  const sf = (s.search_field || "everywhere").trim();
  if (sf && sf !== "everywhere") p.append("search_field", sf);
  for (const a of s.area || []) p.append("area", String(a));
  for (const x of s.schedule || []) p.append("schedule", x);
  for (const e of s.employment || []) p.append("employment", e);
  for (const e of s.experience || []) p.append("experience", e);
  if (s.salary_from) p.append("salary", String(s.salary_from | 0));
  if (s.only_with_salary) p.append("only_with_salary", "true");
  if (s.search_period) p.append("search_period", String(s.search_period | 0));
  p.append("order_by", "publication_time");
  p.append("per_page", "100");
  const out = [];
  let found = null;
  for (let page = 0; page < 20 && out.length < maxResults; page++) {
    const params = new URLSearchParams(p);
    params.append("page", String(page));
    let data;
    try {
      data = await getJson(`${OFFICIAL_URL}?${params}`, {
        "User-Agent": userAgent,
        Authorization: `Bearer ${token2}`,
        Accept: "application/json"
      });
    } catch (e) {
      console.log("[hh] official error:", e.message);
      break;
    }
    found = data.found ?? found;
    for (const raw of data.items || []) {
      out.push(normalizeOfficial(raw));
      if (out.length >= maxResults) break;
    }
    if (page >= (data.pages || 1) - 1) break;
    await sleep2(400);
  }
  return { items: out, total: found };
}
async function search(s, maxResults = 50) {
  const token2 = process.env.HH_ACCESS_TOKEN || "";
  if (token2) {
    const ua = process.env.HH_USER_AGENT || "hh-vacancy-dashboard/1.0 (admin@yourdomain.ru)";
    return searchOfficial(s, token2, ua, maxResults);
  }
  return searchShards(s, maxResults);
}

// netlify/lib/filters.mjs
function applyFilters(vacancies, s) {
  const minRating = parseFloat(s.min_employer_rating || 0);
  const excludes = (s.exclude_keywords || []).map((w) => w.toLowerCase());
  const sf = (s.search_field || "everywhere").trim();
  const words = (s.text || "").trim().toLowerCase().split(/\s+/).filter((w) => w.length > 2);
  return vacancies.filter((v) => {
    if (minRating && (v.rating || 0) < minRating) return false;
    const name = (v.name || "").toLowerCase();
    if (excludes.length && excludes.some((w) => name.includes(w))) return false;
    if (sf === "name" && words.length && !words.every((w) => name.includes(w))) return false;
    return true;
  });
}
var CUR = { RUR: "\u20BD", RUB: "\u20BD", KZT: "\u20B8", USD: "$", EUR: "\u20AC" };
function salaryText(v) {
  const cur = CUR[v.currency] || v.currency || "";
  const fmt = (n) => n.toLocaleString("ru-RU");
  if (v.salary_from && v.salary_to) return `${fmt(v.salary_from)}\u2013${fmt(v.salary_to)} ${cur}`;
  if (v.salary_from) return `\u043E\u0442 ${fmt(v.salary_from)} ${cur}`;
  if (v.salary_to) return `\u0434\u043E ${fmt(v.salary_to)} ${cur}`;
  return "\u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430";
}
var SCHEDULE_RU = {
  remote: "\u0423\u0434\u0430\u043B\u0451\u043D\u043D\u043E",
  fullDay: "\u041F\u043E\u043B\u043D\u044B\u0439 \u0434\u0435\u043D\u044C",
  shift: "\u0421\u043C\u0435\u043D\u043D\u044B\u0439",
  flexible: "\u0413\u0438\u0431\u043A\u0438\u0439",
  flyInFlyOut: "\u0412\u0430\u0445\u0442\u0430"
};
var esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function formatVacancy(v, searchNames = "") {
  const sched = SCHEDULE_RU[v.schedule] || v.schedule || "";
  const rating = v.rating ? `\u2B50 ${Number(v.rating).toFixed(1)} (${v.reviews_count || 0})` : "\u0431\u0435\u0437 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0430";
  const lines = [
    `\u{1F4BC} <b>${esc(v.name)}</b>`,
    `\u{1F3E2} ${esc(v.employer)} \xB7 ${rating}`,
    `\u{1F4CD} ${esc(v.area)}${sched ? ` \xB7 ${sched}` : ""}`,
    `\u{1F4B0} ${salaryText(v)}`
  ];
  if (searchNames) lines.push(`\u{1F50E} <i>${esc(searchNames)}</i>`);
  lines.push(`\u{1F517} ${v.url}`);
  return lines.join("\n");
}

// netlify/lib/tg.mjs
var token = () => process.env.TELEGRAM_BOT_TOKEN || "";
async function call(method, payload = {}) {
  const res = await fetch(`https://api.telegram.org/bot${token()}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(`${method}: ${JSON.stringify(data).slice(0, 200)}`);
  return data.result;
}
var sendMessage = (chatId, text, extra = {}) => call("sendMessage", {
  chat_id: String(chatId),
  text,
  parse_mode: "HTML",
  disable_web_page_preview: true,
  ...extra
});

// netlify/lib/seeds.mjs
var SEEDS = [
  {
    id: "terapevt",
    name: "\u0412\u0440\u0430\u0447-\u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442",
    text: "\u0432\u0440\u0430\u0447 \u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442",
    search_field: "everywhere",
    area: [113],
    schedule: [],
    employment: [],
    experience: [],
    salary_from: 0,
    only_with_salary: false,
    search_period: 3,
    min_employer_rating: 0,
    exclude_keywords: [],
    max_results: 50,
    enabled: true
  },
  {
    id: "telemed",
    name: "\u0422\u0435\u043B\u0435\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430",
    text: "\u0442\u0435\u043B\u0435\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430",
    search_field: "everywhere",
    area: [113],
    schedule: [],
    employment: [],
    experience: [],
    salary_from: 0,
    only_with_salary: false,
    search_period: 3,
    min_employer_rating: 0,
    exclude_keywords: [],
    max_results: 50,
    enabled: true
  }
];

// netlify/functions/fetch-vacancies.mjs
var nowMSK = () => new Date(Date.now() + 3 * 3600 * 1e3).toISOString().slice(0, 16).replace("T", " ");
async function handler() {
  const subs = await storeGet("subs", {}) || {};
  const seenAll = await storeGet("seen", {}) || {};
  const chatIds = Object.keys(subs);
  console.log(`[fetch] chats: ${chatIds.length}`);
  const cacheMerged = /* @__PURE__ */ new Map();
  for (const chatId of chatIds) {
    const u = subs[chatId];
    const own = (u.searches || []).filter((s) => s.enabled !== false);
    const searches = [...SEEDS.filter((s) => s.enabled !== false), ...own];
    if (!searches.length) continue;
    const seen = new Set(seenAll[chatId] || []);
    const merged = /* @__PURE__ */ new Map();
    for (const s of searches) {
      const sid = s.id || s.name;
      const sname = s.personal ? s.name : s.name;
      let items = [];
      try {
        const r = await search(s, s.max_results || 50);
        console.log(`[fetch] ${chatId} '${sname}': found=${r.total} got=${r.items.length}`);
        items = applyFilters(r.items, s);
      } catch (e) {
        console.log("[fetch] search error:", e.message);
        continue;
      }
      for (const v of items) {
        const vid = String(v.id);
        if (!merged.has(vid)) {
          merged.set(vid, { ...v, search_ids: [], search_names: [] });
        }
        const m = merged.get(vid);
        if (!m.search_ids.includes(sid)) m.search_ids.push(sid);
        if (!m.search_names.includes(sname)) m.search_names.push(sname);
        if (!cacheMerged.has(vid)) cacheMerged.set(vid, m);
        else {
          const c = cacheMerged.get(vid);
          for (const x of m.search_ids) if (!c.search_ids.includes(x)) c.search_ids.push(x);
          for (const x of m.search_names) if (!c.search_names.includes(x)) c.search_names.push(x);
        }
      }
    }
    const fresh = [...merged.values()].filter((m) => !seen.has(String(m.id)));
    for (const m of merged.values()) seen.add(String(m.id));
    seenAll[chatId] = [...seen].slice(-5e3);
    if (!fresh.length) {
      console.log(`[fetch] ${chatId}: nothing new`);
      continue;
    }
    try {
      await sendMessage(chatId, `\u{1F195} <b>${fresh.length} \u043D\u043E\u0432\u044B\u0445</b> \u0437\u0430 3 \u0447\u0430\u0441\u0430`);
      let sent = 0;
      for (const m of fresh.slice(0, 10)) {
        await sendMessage(chatId, formatVacancy(m, m.search_names.join(" \xB7 ")));
        sent++;
      }
      console.log(`[fetch] ${chatId}: sent ${sent}`);
    } catch (e) {
      console.log(`[fetch] ${chatId} send failed:`, e.message);
    }
  }
  await storeSet("seen", seenAll);
  const vacancies = [...cacheMerged.values()].sort((a, b) => String(b.published_at || "").localeCompare(String(a.published_at || "")));
  await storeSet("cache", { generated_at: nowMSK(), vacancies });
  console.log(`[fetch] cache: ${vacancies.length} vacancies`);
  return { statusCode: 200, body: JSON.stringify({ chats: chatIds.length, vacancies: vacancies.length }) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
