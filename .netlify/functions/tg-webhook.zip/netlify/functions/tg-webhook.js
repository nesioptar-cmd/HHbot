var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js
var NF_ERROR, NF_REQUEST_ID, BlobsInternalError, collectIterator, base64Decode, base64Encode, getEnvironment, getEnvironmentContext, setEnvironmentContext, MissingBlobsEnvironmentError, BASE64_PREFIX, METADATA_HEADER_INTERNAL, METADATA_HEADER_EXTERNAL, METADATA_MAX_SIZE, encodeMetadata, decodeMetadata, getMetadataFromResponse, BlobsConsistencyError, REGION_AUTO, regions, isValidRegion, InvalidBlobsRegionError, DEFAULT_RETRY_DELAY, MIN_RETRY_DELAY, MAX_RETRY, RATE_LIMIT_HEADER, fetchAndRetry, getDelay, sleep, SIGNED_URL_ACCEPT_HEADER, Client, getClientOptions;
var init_chunk_XR3MUBBK = __esm({
  "node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js"() {
    NF_ERROR = "x-nf-error";
    NF_REQUEST_ID = "x-nf-request-id";
    BlobsInternalError = class extends Error {
      constructor(res) {
        let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
        if (res.headers.has(NF_REQUEST_ID)) {
          details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
        }
        super(`Netlify Blobs has generated an internal error (${details})`);
        this.name = "BlobsInternalError";
      }
    };
    collectIterator = async (iterator) => {
      const result = [];
      for await (const item of iterator) {
        result.push(item);
      }
      return result;
    };
    base64Decode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input, "base64").toString();
      }
      return atob(input);
    };
    base64Encode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input).toString("base64");
      }
      return btoa(input);
    };
    getEnvironment = () => {
      const { Deno, Netlify, process: process2 } = globalThis;
      return Netlify?.env ?? Deno?.env ?? {
        delete: (key) => delete process2?.env[key],
        get: (key) => process2?.env[key],
        has: (key) => Boolean(process2?.env[key]),
        set: (key, value) => {
          if (process2?.env) {
            process2.env[key] = value;
          }
        },
        toObject: () => process2?.env ?? {}
      };
    };
    getEnvironmentContext = () => {
      const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
      if (typeof context !== "string" || !context) {
        return {};
      }
      const data = base64Decode(context);
      try {
        return JSON.parse(data);
      } catch {
      }
      return {};
    };
    setEnvironmentContext = (context) => {
      const encodedContext = base64Encode(JSON.stringify(context));
      getEnvironment().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
    };
    MissingBlobsEnvironmentError = class extends Error {
      constructor(requiredProperties) {
        super(
          `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
            ", "
          )}`
        );
        this.name = "MissingBlobsEnvironmentError";
      }
    };
    BASE64_PREFIX = "b64;";
    METADATA_HEADER_INTERNAL = "x-amz-meta-user";
    METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
    METADATA_MAX_SIZE = 2 * 1024;
    encodeMetadata = (metadata) => {
      if (!metadata) {
        return null;
      }
      const encodedObject = base64Encode(JSON.stringify(metadata));
      const payload = `b64;${encodedObject}`;
      if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
        throw new Error("Metadata object exceeds the maximum size");
      }
      return payload;
    };
    decodeMetadata = (header) => {
      if (!header || !header.startsWith(BASE64_PREFIX)) {
        return {};
      }
      const encodedData = header.slice(BASE64_PREFIX.length);
      const decodedData = base64Decode(encodedData);
      const metadata = JSON.parse(decodedData);
      return metadata;
    };
    getMetadataFromResponse = (response) => {
      if (!response.headers) {
        return {};
      }
      const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
      try {
        return decodeMetadata(value);
      } catch {
        throw new Error(
          "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
        );
      }
    };
    BlobsConsistencyError = class extends Error {
      constructor() {
        super(
          `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
        );
        this.name = "BlobsConsistencyError";
      }
    };
    REGION_AUTO = "auto";
    regions = {
      "us-east-1": true,
      "us-east-2": true,
      "eu-central-1": true,
      "ap-southeast-1": true,
      "ap-southeast-2": true
    };
    isValidRegion = (input) => Object.keys(regions).includes(input);
    InvalidBlobsRegionError = class extends Error {
      constructor(region) {
        super(
          `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
        );
        this.name = "InvalidBlobsRegionError";
      }
    };
    DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
    MIN_RETRY_DELAY = 1e3;
    MAX_RETRY = 5;
    RATE_LIMIT_HEADER = "X-RateLimit-Reset";
    fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
      try {
        const res = await fetch2(url, options);
        if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
          const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
          await sleep(delay);
          return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
        }
        return res;
      } catch (error) {
        if (attemptsLeft === 0) {
          throw error;
        }
        const delay = getDelay();
        await sleep(delay);
        return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
      }
    };
    getDelay = (rateLimitReset) => {
      if (!rateLimitReset) {
        return DEFAULT_RETRY_DELAY;
      }
      return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
    };
    sleep = (ms) => new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
    SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
    Client = class {
      constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token: token2, uncachedEdgeURL }) {
        this.apiURL = apiURL;
        this.consistency = consistency ?? "eventual";
        this.edgeURL = edgeURL;
        this.fetch = fetch2 ?? globalThis.fetch;
        this.region = region;
        this.siteID = siteID;
        this.token = token2;
        this.uncachedEdgeURL = uncachedEdgeURL;
        if (!this.fetch) {
          throw new Error(
            "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
          );
        }
      }
      async getFinalRequest({
        consistency: opConsistency,
        key,
        metadata,
        method,
        parameters = {},
        storeName
      }) {
        const encodedMetadata = encodeMetadata(metadata);
        const consistency = opConsistency ?? this.consistency;
        let urlPath = `/${this.siteID}`;
        if (storeName) {
          urlPath += `/${storeName}`;
        }
        if (key) {
          urlPath += `/${key}`;
        }
        if (this.edgeURL) {
          if (consistency === "strong" && !this.uncachedEdgeURL) {
            throw new BlobsConsistencyError();
          }
          const headers = {
            authorization: `Bearer ${this.token}`
          };
          if (encodedMetadata) {
            headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
          }
          if (this.region) {
            urlPath = `/region:${this.region}${urlPath}`;
          }
          const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
          for (const key2 in parameters) {
            url2.searchParams.set(key2, parameters[key2]);
          }
          return {
            headers,
            url: url2.toString()
          };
        }
        const apiHeaders = { authorization: `Bearer ${this.token}` };
        const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
        for (const key2 in parameters) {
          url.searchParams.set(key2, parameters[key2]);
        }
        if (this.region) {
          url.searchParams.set("region", this.region);
        }
        if (storeName === void 0 || key === void 0) {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        if (encodedMetadata) {
          apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
        }
        if (method === "head" || method === "delete") {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        const res = await this.fetch(url.toString(), {
          headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
          method
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        const { url: signedURL } = await res.json();
        const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
        return {
          headers: userHeaders,
          url: signedURL
        };
      }
      async makeRequest({
        body,
        consistency,
        headers: extraHeaders,
        key,
        metadata,
        method,
        parameters,
        storeName
      }) {
        const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
          consistency,
          key,
          metadata,
          method,
          parameters,
          storeName
        });
        const headers = {
          ...baseHeaders,
          ...extraHeaders
        };
        if (method === "put") {
          headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
        }
        const options = {
          body,
          headers,
          method
        };
        if (body instanceof ReadableStream) {
          options.duplex = "half";
        }
        return fetchAndRetry(this.fetch, url, options);
      }
    };
    getClientOptions = (options, contextOverride) => {
      const context = contextOverride ?? getEnvironmentContext();
      const siteID = context.siteID ?? options.siteID;
      const token2 = context.token ?? options.token;
      if (!siteID || !token2) {
        throw new MissingBlobsEnvironmentError(["siteID", "token"]);
      }
      if (options.region !== void 0 && !isValidRegion(options.region)) {
        throw new InvalidBlobsRegionError(options.region);
      }
      const clientOptions = {
        apiURL: context.apiURL ?? options.apiURL,
        consistency: options.consistency,
        edgeURL: context.edgeURL ?? options.edgeURL,
        fetch: options.fetch,
        region: options.region,
        siteID,
        token: token2,
        uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
      };
      return clientOptions;
    };
  }
});

// node_modules/@netlify/blobs/dist/main.js
var main_exports = {};
__export(main_exports, {
  connectLambda: () => connectLambda,
  getDeployStore: () => getDeployStore,
  getStore: () => getStore,
  listStores: () => listStores,
  setEnvironmentContext: () => setEnvironmentContext
});
function listStores(options = {}) {
  const context = getEnvironmentContext();
  const clientOptions = getClientOptions(options, context);
  const client = new Client(clientOptions);
  const iterator = getListIterator(client, SITE_STORE_PREFIX);
  if (options.paginate) {
    return iterator;
  }
  return collectIterator(iterator).then((results) => ({ stores: results.flatMap((page) => page.stores) }));
}
var connectLambda, DEPLOY_STORE_PREFIX, LEGACY_STORE_INTERNAL_PREFIX, SITE_STORE_PREFIX, Store, getDeployStore, getStore, formatListStoreResponse, getListIterator;
var init_main = __esm({
  "node_modules/@netlify/blobs/dist/main.js"() {
    init_chunk_XR3MUBBK();
    connectLambda = (event) => {
      const rawData = base64Decode(event.blobs);
      const data = JSON.parse(rawData);
      const environmentContext = {
        deployID: event.headers["x-nf-deploy-id"],
        edgeURL: data.url,
        siteID: event.headers["x-nf-site-id"],
        token: data.token
      };
      setEnvironmentContext(environmentContext);
    };
    DEPLOY_STORE_PREFIX = "deploy:";
    LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
    SITE_STORE_PREFIX = "site:";
    Store = class _Store {
      constructor(options) {
        this.client = options.client;
        if ("deployID" in options) {
          _Store.validateDeployID(options.deployID);
          let name = DEPLOY_STORE_PREFIX + options.deployID;
          if (options.name) {
            name += `:${options.name}`;
          }
          this.name = name;
        } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
          const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
          _Store.validateStoreName(storeName);
          this.name = storeName;
        } else {
          _Store.validateStoreName(options.name);
          this.name = SITE_STORE_PREFIX + options.name;
        }
      }
      async delete(key) {
        const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
        if (![200, 204, 404].includes(res.status)) {
          throw new BlobsInternalError(res);
        }
      }
      async get(key, options) {
        const { consistency, type } = options ?? {};
        const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        if (type === void 0 || type === "text") {
          return res.text();
        }
        if (type === "arrayBuffer") {
          return res.arrayBuffer();
        }
        if (type === "blob") {
          return res.blob();
        }
        if (type === "json") {
          return res.json();
        }
        if (type === "stream") {
          return res.body;
        }
        throw new BlobsInternalError(res);
      }
      async getMetadata(key, { consistency } = {}) {
        const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const etag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag,
          metadata
        };
        return result;
      }
      async getWithMetadata(key, options) {
        const { consistency, etag: requestETag, type } = options ?? {};
        const headers = requestETag ? { "if-none-match": requestETag } : void 0;
        const res = await this.client.makeRequest({
          consistency,
          headers,
          key,
          method: "get",
          storeName: this.name
        });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const responseETag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag: responseETag,
          metadata
        };
        if (res.status === 304 && requestETag) {
          return { data: null, ...result };
        }
        if (type === void 0 || type === "text") {
          return { data: await res.text(), ...result };
        }
        if (type === "arrayBuffer") {
          return { data: await res.arrayBuffer(), ...result };
        }
        if (type === "blob") {
          return { data: await res.blob(), ...result };
        }
        if (type === "json") {
          return { data: await res.json(), ...result };
        }
        if (type === "stream") {
          return { data: res.body, ...result };
        }
        throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
      }
      list(options = {}) {
        const iterator = this.getListIterator(options);
        if (options.paginate) {
          return iterator;
        }
        return collectIterator(iterator).then(
          (items) => items.reduce(
            (acc, item) => ({
              blobs: [...acc.blobs, ...item.blobs],
              directories: [...acc.directories, ...item.directories]
            }),
            { blobs: [], directories: [] }
          )
        );
      }
      async set(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const res = await this.client.makeRequest({
          body: data,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      async setJSON(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const payload = JSON.stringify(data);
        const headers = {
          "content-type": "application/json"
        };
        const res = await this.client.makeRequest({
          body: payload,
          headers,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      static formatListResultBlob(result) {
        if (!result.key) {
          return null;
        }
        return {
          etag: result.etag,
          key: result.key
        };
      }
      static validateKey(key) {
        if (key === "") {
          throw new Error("Blob key must not be empty.");
        }
        if (key.startsWith("/") || key.startsWith("%2F")) {
          throw new Error("Blob key must not start with forward slash (/).");
        }
        if (new TextEncoder().encode(key).length > 600) {
          throw new Error(
            "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
          );
        }
      }
      static validateDeployID(deployID) {
        if (!/^\w{1,24}$/.test(deployID)) {
          throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
        }
      }
      static validateStoreName(name) {
        if (name.includes("/") || name.includes("%2F")) {
          throw new Error("Store name must not contain forward slashes (/).");
        }
        if (new TextEncoder().encode(name).length > 64) {
          throw new Error(
            "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
          );
        }
      }
      getListIterator(options) {
        const { client, name: storeName } = this;
        const parameters = {};
        if (options?.prefix) {
          parameters.prefix = options.prefix;
        }
        if (options?.directories) {
          parameters.directories = "true";
        }
        return {
          [Symbol.asyncIterator]() {
            let currentCursor = null;
            let done = false;
            return {
              async next() {
                if (done) {
                  return { done: true, value: void 0 };
                }
                const nextParameters = { ...parameters };
                if (currentCursor !== null) {
                  nextParameters.cursor = currentCursor;
                }
                const res = await client.makeRequest({
                  method: "get",
                  parameters: nextParameters,
                  storeName
                });
                let blobs2 = [];
                let directories = [];
                if (![200, 204, 404].includes(res.status)) {
                  throw new BlobsInternalError(res);
                }
                if (res.status === 404) {
                  done = true;
                } else {
                  const page = await res.json();
                  if (page.next_cursor) {
                    currentCursor = page.next_cursor;
                  } else {
                    done = true;
                  }
                  blobs2 = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                  directories = page.directories ?? [];
                }
                return {
                  done: false,
                  value: {
                    blobs: blobs2,
                    directories
                  }
                };
              }
            };
          }
        };
      }
    };
    getDeployStore = (input = {}) => {
      const context = getEnvironmentContext();
      const options = typeof input === "string" ? { name: input } : input;
      const deployID = options.deployID ?? context.deployID;
      if (!deployID) {
        throw new MissingBlobsEnvironmentError(["deployID"]);
      }
      const clientOptions = getClientOptions(options, context);
      if (!clientOptions.region) {
        if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
          if (!context.primaryRegion) {
            throw new Error(
              "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the `getDeployStore` options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
            );
          }
          clientOptions.region = context.primaryRegion;
        } else {
          clientOptions.region = REGION_AUTO;
        }
      }
      const client = new Client(clientOptions);
      return new Store({ client, deployID, name: options.name });
    };
    getStore = (input) => {
      if (typeof input === "string") {
        const clientOptions = getClientOptions({});
        const client = new Client(clientOptions);
        return new Store({ client, name: input });
      }
      if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
        const { name, siteID, token: token2 } = input;
        const clientOptions = getClientOptions(input, { siteID, token: token2 });
        if (!name || !siteID || !token2) {
          throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.name === "string") {
        const { name } = input;
        const clientOptions = getClientOptions(input);
        if (!name) {
          throw new MissingBlobsEnvironmentError(["name"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.deployID === "string") {
        const clientOptions = getClientOptions(input);
        const { deployID } = input;
        if (!deployID) {
          throw new MissingBlobsEnvironmentError(["deployID"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, deployID });
      }
      throw new Error(
        "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
      );
    };
    formatListStoreResponse = (stores) => stores.filter((store) => !store.startsWith(DEPLOY_STORE_PREFIX)).map((store) => store.startsWith(SITE_STORE_PREFIX) ? store.slice(SITE_STORE_PREFIX.length) : store);
    getListIterator = (client, prefix) => {
      const parameters = {
        prefix
      };
      return {
        [Symbol.asyncIterator]() {
          let currentCursor = null;
          let done = false;
          return {
            async next() {
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters
              });
              if (res.status === 404) {
                return { done: true, value: void 0 };
              }
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              return {
                done: false,
                value: {
                  ...page,
                  stores: formatListStoreResponse(page.stores)
                }
              };
            }
          };
        }
      };
    };
  }
});

// netlify/functions/tg-webhook.mjs
var tg_webhook_exports = {};
__export(tg_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(tg_webhook_exports);

// netlify/lib/store.mjs
var import_node_fs = __toESM(require("fs"), 1);
var import_node_path = __toESM(require("path"), 1);
var FILE_DIR = process.env.FILE_STORE_DIR || ".tmp-store";
function fileGet(key, fallback) {
  try {
    const p = import_node_path.default.join(FILE_DIR, key + ".json");
    if (!import_node_fs.default.existsSync(p)) return fallback;
    return JSON.parse(import_node_fs.default.readFileSync(p, "utf8"));
  } catch {
    return fallback;
  }
}
function fileSet(key, val) {
  import_node_fs.default.mkdirSync(FILE_DIR, { recursive: true });
  import_node_fs.default.writeFileSync(import_node_path.default.join(FILE_DIR, key + ".json"), JSON.stringify(val));
}
var blobStore = null;
async function blobs() {
  if (blobStore) return blobStore;
  const { getStore: getStore2 } = await Promise.resolve().then(() => (init_main(), main_exports));
  if (process.env.BLOBS_SITE_ID && process.env.BLOBS_TOKEN) {
    blobStore = getStore2({
      name: "hhbot",
      siteID: process.env.BLOBS_SITE_ID,
      token: process.env.BLOBS_TOKEN
    });
  } else {
    blobStore = getStore2("hhbot");
  }
  return blobStore;
}
async function storeGet(key, fallback = null) {
  if (process.env.STORE === "file") return fileGet(key, fallback);
  try {
    const v = await (await blobs()).get(key, { type: "json" });
    return v ?? fallback;
  } catch (e) {
    console.log("[store] get failed, fallback:", e.message);
    return fallback;
  }
}
async function storeSet(key, val) {
  if (process.env.STORE === "file") return fileSet(key, val);
  await (await blobs()).setJSON(key, val);
}

// netlify/lib/tg.mjs
var token = () => process.env.TELEGRAM_BOT_TOKEN || "";
async function call(method, payload = {}) {
  const res = await fetch(`https://api.telegram.org/bot${token()}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(`${method}: ${JSON.stringify(data).slice(0, 200)}`);
  return data.result;
}
var sendMessage = (chatId, text, extra = {}) => call("sendMessage", {
  chat_id: String(chatId),
  text,
  parse_mode: "HTML",
  disable_web_page_preview: true,
  ...extra
});
var editMessage = (chatId, messageId, text, replyMarkup) => call("editMessageText", {
  chat_id: String(chatId),
  message_id: messageId,
  text,
  parse_mode: "HTML",
  disable_web_page_preview: true,
  ...replyMarkup ? { reply_markup: replyMarkup } : {}
});
var answerCallback = (id, text = "") => call("answerCallbackQuery", { callback_query_id: id, ...text ? { text } : {} });

// netlify/lib/bot.mjs
var AREA_IDS = { 1: "\u041C\u043E\u0441\u043A\u0432\u0430", 2: "\u0421\u041F\u0431", 113: "\u0420\u043E\u0441\u0441\u0438\u044F" };
var FIELD_RU = {
  everywhere: "\u0432\u0435\u0437\u0434\u0435",
  name: "\u0432 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0438",
  description: "\u0432 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438",
  company_name: "\u0432 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438"
};
var EXP_RU = {
  noExperience: "\u0431\u0435\u0437 \u043E\u043F\u044B\u0442\u0430",
  between1And3: "1\u20133 \u0433\u043E\u0434\u0430",
  between3And6: "3\u20136 \u043B\u0435\u0442",
  moreThan6: "6+ \u043B\u0435\u0442"
};
function blankDraft(text = "") {
  return {
    text,
    search_field: "everywhere",
    area: [113],
    schedule: [],
    employment: [],
    experience: [],
    salary_from: 0,
    only_with_salary: false,
    search_period: 7,
    min_employer_rating: 0,
    exclude_keywords: [],
    max_results: 30,
    enabled: true
  };
}
function describe(s) {
  const bits = [`\xAB${s.text}\xBB`, `\u0438\u0449\u0435\u043C ${FIELD_RU[s.search_field] || "\u0432\u0435\u0437\u0434\u0435"}`];
  bits.push("\u0440\u0435\u0433\u0438\u043E\u043D: " + (s.area || []).map((a) => AREA_IDS[a] || a).join(","));
  const sch = s.schedule || [];
  bits.push("\u0433\u0440\u0430\u0444\u0438\u043A: " + (sch.length ? sch.join(",") : "\u043B\u044E\u0431\u043E\u0439"));
  if (s.salary_from) bits.push(`\u043E\u0442 ${Number(s.salary_from).toLocaleString("ru-RU")} \u20BD`);
  if (s.min_employer_rating) bits.push(`\u0440\u0435\u0439\u0442\u0438\u043D\u0433 \u2265 ${s.min_employer_rating}`);
  if (s.experience?.length) bits.push("\u043E\u043F\u044B\u0442: " + s.experience.map((e) => EXP_RU[e] || e).join(","));
  if (!s.enabled) bits.push("\u23F8 \u0432\u044B\u043A\u043B");
  return bits.join(" \xB7 ");
}
var AREA_ALIASES = { 1: [1], "\u043C\u043E\u0441\u043A\u0432\u0430": [1], "\u043C\u0441\u043A": [1], 2: [2], "\u043F\u0438\u0442\u0435\u0440": [2], "\u0441\u043F\u0431": [2], 113: [113], "\u0440\u043E\u0441\u0441\u0438\u044F": [113], "\u0432\u0441\u044F": [113] };
var FIELD_ALIASES = {
  "\u0432\u0435\u0437\u0434\u0435": "everywhere",
  "everywhere": "everywhere",
  "\u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435": "name",
  "name": "name",
  "\u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435": "description",
  "description": "description",
  "\u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F": "company_name",
  "company": "company_name"
};
var EXP_ALIASES = {
  "any": "",
  "\u043D\u0435 \u0432\u0430\u0436\u043D\u043E": "",
  "\u0431\u0435\u0437 \u043E\u043F\u044B\u0442\u0430": "noExperience",
  "\u043D\u0435\u0442 \u043E\u043F\u044B\u0442\u0430": "noExperience",
  "1-3": "between1And3",
  "1\u20133": "between1And3",
  "3-6": "between3And6",
  "3\u20136": "between3And6",
  "6+": "moreThan6",
  "\u0431\u043E\u043B\u0435\u0435 6": "moreThan6"
};
var SCHED_ALIASES = {
  "remote": ["remote"],
  "\u0443\u0434\u0430\u043B\u0451\u043D\u043D\u043E": ["remote"],
  "fullday": ["fullDay"],
  "\u043F\u043E\u043B\u043D\u044B\u0439": ["fullDay"],
  "flexible": ["flexible"],
  "\u0433\u0438\u0431\u043A\u0438\u0439": ["flexible"],
  "shift": ["shift"],
  "\u0441\u043C\u0435\u043D\u043D\u044B\u0439": ["shift"],
  "vahta": ["flyInFlyOut"],
  "\u0432\u0430\u0445\u0442\u0430": ["flyInFlyOut"],
  "any": ["any"],
  "\u043B\u044E\u0431\u043E\u0439": ["any"]
};
function parseSpec(spec) {
  const s = blankDraft("");
  const texts = [];
  for (const raw of spec.split("|")) {
    const part = raw.trim();
    if (!part) continue;
    const low = part.toLowerCase();
    if (AREA_ALIASES[low]) {
      s.area = AREA_ALIASES[low];
      continue;
    }
    const sch = SCHED_ALIASES[low];
    if (sch) {
      s.schedule = sch[0] === "any" ? [] : sch;
      continue;
    }
    if (FIELD_ALIASES[low]) {
      s.search_field = FIELD_ALIASES[low];
      continue;
    }
    if (low in EXP_ALIASES) {
      s.experience = EXP_ALIASES[low] ? [EXP_ALIASES[low]] : [];
      continue;
    }
    const digits = part.replace(/\D/g, "");
    if (digits && low.replace(/[\s\u00a0]/g, "") === digits) {
      const num = parseInt(digits, 10);
      if (num <= 5 && !s.min_employer_rating) s.min_employer_rating = num;
      else s.salary_from = num;
      continue;
    }
    const r = parseFloat(part.replace(",", "."));
    if (!isNaN(r) && r > 0 && r <= 5 && !s.min_employer_rating) {
      s.min_employer_rating = r;
      continue;
    }
    texts.push(part);
  }
  s.text = texts.join(" ").trim().slice(0, 100);
  s.name = `\u{1F464} ${s.text.slice(0, 40)}`;
  return s;
}
var btn = (text, cb) => ({ text, callback_data: cb });
function mainMenu() {
  return {
    text: "\u{1F916} <b>\u041C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043D\u0433 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 hh.ru</b>\n\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043A\u0430\u0436\u0434\u044B\u0435 3 \u0447\u0430\u0441\u0430. \u0427\u0442\u043E \u0434\u0435\u043B\u0430\u0435\u043C?",
    kb: { inline_keyboard: [
      [btn("\u{1F50D} \u041D\u043E\u0432\u0430\u044F \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0430", "menu:new")],
      [btn("\u{1F4CB} \u041C\u043E\u0438 \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0438", "menu:list")],
      [btn("\u{1F4CA} \u0414\u0430\u0448\u0431\u043E\u0440\u0434", "menu:dash")],
      [btn("\u2753 \u041F\u043E\u043C\u043E\u0449\u044C", "menu:help")]
    ] }
  };
}
function wizardMenu(draft) {
  const mark = (cur, v) => cur === v ? "\u2705 " : "";
  const f = draft.search_field || "everywhere";
  const a = String((draft.area || [113])[0]);
  const sch = (draft.schedule || [])[0] || "any";
  const r = draft.min_employer_rating >= 4.5 ? "4.5" : draft.min_employer_rating >= 4 ? "4.0" : "0";
  const sal = draft.salary_from || 0;
  const salBtn = (v, l) => btn((sal === v ? "\u2705 " : "") + l, `wiz:salary:${v}`);
  return {
    text: `\u2699\uFE0F <b>\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \xAB${draft.text}\xBB</b>
\u0421\u0435\u0439\u0447\u0430\u0441: ${describe(draft)}
\u041D\u0430\u0436\u0438\u043C\u0430\u0439\u0442\u0435 \u043A\u043D\u043E\u043F\u043A\u0438, \u0437\u0430\u0442\u0435\u043C \xAB\u041F\u043E\u0434\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F\xBB.`,
    kb: { inline_keyboard: [
      ["everywhere", "name", "description"].map((v) => btn(mark(f, v) + { everywhere: "\u0412\u0435\u0437\u0434\u0435", name: "\u0412 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0438", description: "\u0412 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438" }[v], `wiz:field:${v}`)),
      ["1", "2", "113"].map((v) => btn(mark(a, v) + { 1: "\u041C\u043E\u0441\u043A\u0432\u0430", 2: "\u0421\u041F\u0431", 113: "\u0420\u043E\u0441\u0441\u0438\u044F" }[v], `wiz:area:${v}`)),
      [["any", "\u041B\u044E\u0431\u043E\u0439"], ["remote", "\u0423\u0434\u0430\u043B\u0451\u043D\u043D\u043E"], ["fullDay", "\u041F\u043E\u043B\u043D\u044B\u0439 \u0434\u0435\u043D\u044C"]].map(([v, l]) => btn(mark(sch, v) + l, `wiz:schedule:${v}`)),
      [["0", "\u041B\u044E\u0431\u043E\u0439"], ["4.0", "4.0+"], ["4.5", "4.5+"]].map(([v, l]) => btn(mark(r, v) + l, `wiz:rating:${v}`)),
      [salBtn(0, "\u041B\u044E\u0431\u0430\u044F"), salBtn(5e4, "50k"), salBtn(1e5, "100k"), salBtn(15e4, "150k")],
      [btn("\u270F\uFE0F \u0421\u0432\u043E\u044F \u0441\u0443\u043C\u043C\u0430", "wiz:salarycustom")],
      [btn("\u2705 \u041F\u043E\u0434\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F", "wiz:done"), btn("\u{1F5D1} \u041E\u0442\u043C\u0435\u043D\u0430", "wiz:cancel")]
    ] }
  };
}
function listMenu(searches) {
  if (!searches.length) {
    return {
      text: "\u041F\u043E\u043A\u0430 \u043F\u0443\u0441\u0442\u043E. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043F\u0435\u0440\u0432\u0443\u044E \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0443:",
      kb: { inline_keyboard: [[btn("\u{1F50D} \u041D\u043E\u0432\u0430\u044F \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0430", "menu:new")], [btn("\u25C0\uFE0F \u041C\u0435\u043D\u044E", "menu:main")]] }
    };
  }
  const rows = searches.map((s, i) => [
    btn(`${s.enabled === false ? "\u23F8" : "\u25B6"} ${i + 1}. ${(s.text || "").slice(0, 24)}`, `sub:toggle:${i}`),
    btn("\u270F\uFE0F", `sub:edit:${i}`),
    btn("\u{1F5D1}", `sub:del:${i}`)
  ]);
  rows.push([btn("\u{1F50D} \u041D\u043E\u0432\u0430\u044F", "menu:new"), btn("\u25C0\uFE0F \u041C\u0435\u043D\u044E", "menu:main")]);
  return {
    text: "\u{1F4CB} <b>\u041C\u043E\u0438 \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0438</b> (\u25B6/\u23F8 \u2014 \u0432\u043A\u043B/\u0432\u044B\u043A\u043B, \u270F\uFE0F \u2014 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C, \u{1F5D1} \u2014 \u0443\u0434\u0430\u043B\u0438\u0442\u044C):",
    kb: { inline_keyboard: rows }
  };
}
var HELP = "\u{1F916} \u042F \u0441\u043B\u0435\u0436\u0443 \u0437\u0430 hh.ru \u043A\u0430\u0436\u0434\u044B\u0435 3 \u0447\u0430\u0441\u0430 \u0438 \u043F\u0440\u0438\u0441\u044B\u043B\u0430\u044E \u043D\u043E\u0432\u044B\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438.\n\n\u2022 <b>\u041D\u043E\u0432\u0430\u044F \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0430</b> \u2014 \u043C\u0430\u0441\u0442\u0435\u0440 \u0441 \u043A\u043D\u043E\u043F\u043A\u0430\u043C\u0438: \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u0441\u043B\u043E\u0432\u0430 \u2192 \u0440\u0435\u0433\u0438\u043E\u043D \u2192 \u0433\u0440\u0430\u0444\u0438\u043A \u2192 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430 \u2192 \u0440\u0435\u0439\u0442\u0438\u043D\u0433.\n\u2022 <b>\u041C\u043E\u0438 \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0438</b> \u2014 \u0432\u043A\u043B/\u0432\u044B\u043A\u043B, \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C, \u0443\u0434\u0430\u043B\u0438\u0442\u044C.\n\u2022 <b>\u0414\u0430\u0448\u0431\u043E\u0440\u0434</b> \u2014 \u0432\u0441\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u0441 \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C\u0438.\n\n\u0411\u044B\u0441\u0442\u0440\u044B\u0435 \u043A\u043E\u043C\u0430\u043D\u0434\u044B: /list, /del 1, /on 1, /off 1, /add <i>\u0442\u0435\u043A\u0441\u0442</i>.";
async function onText(ctx, text, state) {
  const { chatId, username } = ctx;
  const t = (text || "").trim();
  if (t === "/start") {
    state.user = { username };
    state.awaiting = null;
    const m2 = mainMenu();
    await sendMessage(chatId, `\u041F\u0440\u0438\u0432\u0435\u0442, @${username}! ` + m2.text, { reply_markup: m2.kb });
    return;
  }
  if (t === "/help") {
    await sendMessage(chatId, HELP);
    return;
  }
  if (t === "/list") {
    const m2 = listMenu(state.searches);
    await sendMessage(chatId, m2.text, { reply_markup: m2.kb });
    return;
  }
  if (t.startsWith("/add ")) {
    const arg = t.slice(5).trim();
    if (!arg) {
      await sendMessage(chatId, "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435: /add <i>\u0442\u0435\u043A\u0441\u0442</i>");
      return;
    }
    const s = arg.includes("|") ? parseSpec(arg) : { ...blankDraft(arg.slice(0, 100)) };
    if (!s.text) {
      await sendMessage(chatId, "\u041D\u0435 \u043F\u043E\u043D\u044F\u043B \u0437\u0430\u043F\u0440\u043E\u0441. \u041F\u0440\u0438\u043C\u0435\u0440: /add <i>\u0432\u0440\u0430\u0447 \u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442 | \u043C\u043E\u0441\u043A\u0432\u0430</i>");
      return;
    }
    if (!s.name) s.name = `\u{1F464} ${s.text.slice(0, 40)}`;
    state.searches.push(s);
    await sendMessage(chatId, `\u2705 \u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430: ${describe(s)}`);
    return;
  }
  if (t.startsWith("/replace ")) {
    const arg = t.slice(9).trim();
    const head = arg.split("|")[0].trim();
    const n = parseInt(head, 10);
    if (!head.match(/^\d+$/) || !(n >= 1 && n <= state.searches.length)) {
      await sendMessage(chatId, "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435: /replace <i>\u043D\u043E\u043C\u0435\u0440 | \u0442\u0435\u043A\u0441\u0442 | \u2026</i>");
      return;
    }
    const s = parseSpec(arg.slice(arg.indexOf("|") + 1));
    if (!s.text) {
      await sendMessage(chatId, "\u041D\u0435 \u043F\u043E\u043D\u044F\u043B \u0437\u0430\u043F\u0440\u043E\u0441.");
      return;
    }
    state.searches[n - 1] = s;
    await sendMessage(chatId, `\u2705 \u041F\u043E\u0434\u0431\u043E\u0440\u043A\u0430 \u2116${n} \u0437\u0430\u043C\u0435\u043D\u0435\u043D\u0430: ${describe(s)}`);
    return;
  }
  const parts = t.split(/\s+/);
  if ((parts[0] === "/del" || parts[0] === "/on" || parts[0] === "/off") && parts[1]) {
    const n = parseInt(parts[1], 10);
    if (n >= 1 && n <= state.searches.length) {
      if (parts[0] === "/del") {
        const [rm] = state.searches.splice(n - 1, 1);
        await sendMessage(chatId, `\u{1F5D1} \u0423\u0434\u0430\u043B\u0435\u043D\u0430: \xAB${rm.text}\xBB`);
      } else {
        state.searches[n - 1].enabled = parts[0] === "/on";
        await sendMessage(chatId, `\u2705 \u041F\u043E\u0434\u0431\u043E\u0440\u043A\u0430 \u2116${n} ${parts[0] === "/on" ? "\u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0430" : "\u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D\u0430"}.`);
      }
    } else await sendMessage(chatId, "\u041D\u0435\u0442 \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0438 \u0441 \u0442\u0430\u043A\u0438\u043C \u043D\u043E\u043C\u0435\u0440\u043E\u043C. /list");
    return;
  }
  if (state.awaiting === "keyword" && t && !t.startsWith("/")) {
    state.draft = { ...blankDraft(t.slice(0, 100)), editIndex: null };
    state.awaiting = null;
    const m2 = wizardMenu(state.draft);
    const sent = await sendMessage(chatId, m2.text, { reply_markup: m2.kb });
    state.draft.menuMsgId = sent.message_id;
    return;
  }
  if (state.awaiting === "salary" && t && !t.startsWith("/")) {
    const digits = t.replace(/\D/g, "");
    if (digits) {
      state.draft.salary_from = parseInt(digits, 10);
      state.awaiting = null;
      const m2 = wizardMenu(state.draft);
      await editMessage(chatId, state.draft.menuMsgId, m2.text, m2.kb);
    } else await sendMessage(chatId, "\u041F\u0440\u0438\u0448\u043B\u0438\u0442\u0435 \u0441\u0443\u043C\u043C\u0443 \u0447\u0438\u0441\u043B\u043E\u043C, \u043D\u0430\u043F\u0440. 150000, \u0438\u043B\u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C\xBB.");
    return;
  }
  const m = mainMenu();
  await sendMessage(chatId, "\u041D\u0435 \u043F\u043E\u043D\u044F\u043B. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435:", { reply_markup: m.kb });
}
async function onCallback(ctx, data, msgId, state) {
  const { chatId } = ctx;
  const [ns, ...rest] = data.split(":");
  if (ns === "menu") {
    const m = mainMenu();
    if (rest[0] === "new") {
      state.awaiting = "keyword";
      await editMessage(chatId, msgId, "\u{1F50D} <b>\u0427\u0442\u043E \u0438\u0449\u0435\u043C?</b>\n\u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u0441\u043B\u043E\u0432\u0430 \u043E\u0434\u043D\u0438\u043C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435\u043C (\u043D\u0430\u043F\u0440. <i>\u0432\u0440\u0430\u0447 \u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442</i>).");
    } else if (rest[0] === "list") {
      const l = listMenu(state.searches);
      await editMessage(chatId, msgId, l.text, l.kb);
    } else if (rest[0] === "help") {
      await editMessage(chatId, msgId, HELP, { inline_keyboard: [[btn("\u25C0\uFE0F \u041C\u0435\u043D\u044E", "menu:main")]] });
    } else if (rest[0] === "dash") {
      await editMessage(
        chatId,
        msgId,
        `\u{1F4CA} <b>\u0414\u0430\u0448\u0431\u043E\u0440\u0434:</b> ${process.env.DASHBOARD_URL || "(\u0441\u0441\u044B\u043B\u043A\u0430 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u0434\u0435\u043F\u043B\u043E\u044F)"}`,
        { inline_keyboard: [[btn("\u25C0\uFE0F \u041C\u0435\u043D\u044E", "menu:main")]] }
      );
    } else {
      await editMessage(chatId, msgId, m.text, m.kb);
    }
    return;
  }
  if (ns === "wiz") {
    const d = state.draft;
    if (!d) {
      await editMessage(chatId, msgId, "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043F\u043E\u0434\u0431\u043E\u0440\u043A\u0443 \u0437\u0430\u043D\u043E\u0432\u043E:");
      return;
    }
    const [key, val] = rest;
    if (key === "cancel") {
      state.draft = null;
      state.awaiting = null;
      const m2 = mainMenu();
      await editMessage(chatId, msgId, "\u{1F5D1} \u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E.", m2.kb);
      return;
    }
    if (key === "done") {
      const s = { ...d };
      delete s.menuMsgId;
      delete s.editIndex;
      s.name = `\u{1F464} ${s.text.slice(0, 40)}`;
      s.enabled = true;
      if (d.editIndex !== null && d.editIndex !== void 0) {
        state.searches[d.editIndex] = s;
      } else state.searches.push(s);
      state.draft = null;
      state.awaiting = null;
      const m2 = mainMenu();
      await editMessage(chatId, msgId, `\u2705 <b>\u0413\u043E\u0442\u043E\u0432\u043E!</b> \u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0430\u043A\u0442\u0438\u0432\u043D\u0430: ${describe(s)}
\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043A\u0430\u0436\u0434\u044B\u0435 3 \u0447\u0430\u0441\u0430.`, m2.kb);
      return;
    }
    if (key === "field" && ["everywhere", "name", "description"].includes(val)) d.search_field = val;
    else if (key === "area" && ["1", "2", "113"].includes(val)) d.area = [parseInt(val, 10)];
    else if (key === "schedule" && ["any", "remote", "fullDay"].includes(val)) d.schedule = val === "any" ? [] : [val];
    else if (key === "rating" && ["0", "4.0", "4.5"].includes(val)) d.min_employer_rating = parseFloat(val);
    else if (key === "salary" && /^\d+$/.test(val || "")) d.salary_from = parseInt(val, 10);
    else if (key === "salarycustom") {
      state.awaiting = "salary";
      await editMessage(chatId, msgId, "\u{1F4B0} <b>\u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u0441\u0443\u043C\u043C\u0443 \u0447\u0438\u0441\u043B\u043E\u043C</b> (\u043D\u0430\u043F\u0440. 150000) \u0438\u043B\u0438 \u0432\u0435\u0440\u043D\u0438\u0442\u0435\u0441\u044C:", {
        inline_keyboard: [[btn("\u25C0\uFE0F \u041D\u0430\u0437\u0430\u0434", "wiz:back")]]
      });
      return;
    } else if (key === "back") {
    }
    const m = wizardMenu(d);
    await editMessage(chatId, msgId, m.text, m.kb);
    return;
  }
  if (ns === "sub") {
    const [action, idxRaw] = rest;
    const i = parseInt(idxRaw, 10);
    if (!(i >= 0 && i < state.searches.length)) return;
    if (action === "toggle") {
      state.searches[i].enabled = state.searches[i].enabled === false ? true : false;
    } else if (action === "del") {
      state.searches.splice(i, 1);
    } else if (action === "edit") {
      state.draft = { ...state.searches[i], editIndex: i };
      const m = wizardMenu(state.draft);
      const sent = await sendMessage(chatId, m.text, { reply_markup: m.kb });
      state.draft.menuMsgId = sent.message_id;
      return;
    }
    const l = listMenu(state.searches);
    await editMessage(chatId, msgId, l.text, l.kb);
  }
}

// netlify/functions/tg-webhook.mjs
async function loadState(chatId) {
  const subs = await storeGet("subs", {}) || {};
  const drafts = await storeGet("drafts", {}) || {};
  const u = subs[String(chatId)] || { username: "", searches: [] };
  return {
    subs,
    drafts,
    state: {
      username: u.username || "",
      searches: u.searches || [],
      awaiting: drafts[String(chatId)]?.awaiting || null,
      draft: drafts[String(chatId)]?.draft || null
    }
  };
}
async function saveState(chatId, subs, drafts, state) {
  subs[String(chatId)] = { username: state.username, searches: state.searches };
  if (state.draft || state.awaiting) {
    drafts[String(chatId)] = { draft: state.draft, awaiting: state.awaiting };
  } else delete drafts[String(chatId)];
  await storeSet("subs", subs);
  await storeSet("drafts", drafts);
}
async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 200, body: "ok" };
  let update;
  try {
    update = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 200, body: "ok" };
  }
  try {
    if (update.callback_query) {
      const cb = update.callback_query;
      const chatId = cb.message?.chat?.id;
      const username = cb.from?.username || `id${cb.from?.id || "?"}`;
      if (!chatId) return { statusCode: 200, body: "ok" };
      const { subs, drafts, state } = await loadState(chatId);
      state.username = state.username || username;
      await answerCallback(cb.id).catch(() => {
      });
      await onCallback({ chatId, username: state.username }, cb.data || "", cb.message?.message_id, state);
      await saveState(chatId, subs, drafts, state);
    } else if (update.message) {
      const msg = update.message;
      const chatId = msg.chat?.id;
      if (!chatId || msg.chat.type !== "private" || !msg.text) {
        return { statusCode: 200, body: "ok" };
      }
      const username = msg.from?.username || `id${msg.from?.id || "?"}`;
      const { subs, drafts, state } = await loadState(chatId);
      state.username = state.username || username;
      await onText({ chatId, username: state.username }, msg.text, state);
      await saveState(chatId, subs, drafts, state);
    }
  } catch (e) {
    console.log("[webhook] error:", e.message);
  }
  return { statusCode: 200, body: "ok" };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
