var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/debug-run.mjs
var debug_run_exports = {};
__export(debug_run_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(debug_run_exports);

// netlify/lib/hh.mjs
var SHARDS_URL = "https://hh.ru/shards/vacancy/search";
var OFFICIAL_URL = "https://api.hh.ru/vacancies";
var BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function getJson(url, headers = {}) {
  const res = await fetch(url, { headers: { "User-Agent": BROWSER_UA, ...headers } });
  if (!res.ok) throw new Error(`hh.ru HTTP ${res.status}`);
  return res.json();
}
function buildShardsParams(s) {
  const p = new URLSearchParams();
  if (s.text) p.append("text", s.text);
  const sf = (s.search_field || "everywhere").trim();
  if (sf && sf !== "everywhere") p.append("search_field", sf);
  for (const a of s.area || []) p.append("area", String(a));
  for (const x of s.schedule || []) p.append("schedule", x);
  for (const e of s.employment || []) {
    p.append("employment", e);
    p.append("employment_form", e === "full" ? "FULL" : e);
  }
  for (const e of s.experience || []) p.append("experience", e);
  if (s.salary_from) p.append("salary", String(s.salary_from | 0));
  if (s.only_with_salary) p.append("only_with_salary", "true");
  if (s.search_period) p.append("search_period", String(s.search_period | 0));
  p.append("items_on_page", "50");
  return p;
}
function normalizeShards(v) {
  const comp = v.compensation || {};
  const company = v.company || {};
  const reviews = company.employerReviews || {};
  const rating = parseFloat(String(reviews.totalRating || "0").replace(",", ".")) || 0;
  const area = v.area || {};
  const links = v.links || {};
  const formats = [];
  for (const wf of v.workFormats || []) formats.push(...wf.workFormatsElement || []);
  return {
    id: String(v.vacancyId),
    name: v.name || "",
    url: links.desktop || `https://hh.ru/vacancy/${v.vacancyId}`,
    area: area.name || "",
    area_id: String(area["@id"] || ""),
    employer: company.name || company.visibleName || "",
    employer_id: String(company.id || ""),
    rating,
    reviews_count: parseInt(reviews.reviewsCount || 0, 10) || 0,
    salary_from: comp.from ?? null,
    salary_to: comp.to ?? null,
    currency: comp.currencyCode || comp.currency || "",
    schedule: v["@workSchedule"] || "",
    work_formats: formats,
    experience: v.workExperience || "",
    employment: v.employment?.["@type"] || v.employmentForm || "",
    published_at: v.publicationTime?.["$"] || ""
  };
}
async function searchShards(s, maxResults = 50) {
  const base = buildShardsParams(s);
  const out = [];
  let total = null;
  for (let page = 0; page < 40 && out.length < maxResults; page++) {
    const params = new URLSearchParams(base);
    params.append("page", String(page));
    let data;
    try {
      data = await getJson(`${SHARDS_URL}?${params}`);
    } catch (e) {
      console.log("[hh] shards error:", e.message);
      break;
    }
    const r = data.vacancySearchResult || {};
    if (total === null) total = r.totalResults;
    const items = r.vacancies || [];
    if (!items.length) break;
    for (const raw of items) {
      out.push(normalizeShards(raw));
      if (out.length >= maxResults) break;
    }
    const last = r.paging?.lastPage?.page;
    if (last !== void 0 && page >= last) break;
    await sleep(400);
  }
  return { items: out, total };
}
function normalizeOfficial(v) {
  const emp = v.employer || {};
  const sal = v.salary || {};
  return {
    id: String(v.id),
    name: v.name || "",
    url: v.alternate_url || `https://hh.ru/vacancy/${v.id}`,
    area: v.area?.name || "",
    area_id: String(v.area?.id || ""),
    employer: emp.name || "",
    employer_id: String(emp.id || ""),
    rating: 0,
    reviews_count: 0,
    salary_from: sal.from ?? null,
    salary_to: sal.to ?? null,
    currency: sal.currency || "",
    schedule: v.schedule?.id || "",
    work_formats: v.work_format || [],
    experience: v.experience?.id || "",
    employment: v.employment?.id || "",
    published_at: v.published_at || ""
  };
}
async function searchOfficial(s, token, userAgent, maxResults = 50) {
  const p = new URLSearchParams();
  if (s.text) p.append("text", s.text);
  const sf = (s.search_field || "everywhere").trim();
  if (sf && sf !== "everywhere") p.append("search_field", sf);
  for (const a of s.area || []) p.append("area", String(a));
  for (const x of s.schedule || []) p.append("schedule", x);
  for (const e of s.employment || []) p.append("employment", e);
  for (const e of s.experience || []) p.append("experience", e);
  if (s.salary_from) p.append("salary", String(s.salary_from | 0));
  if (s.only_with_salary) p.append("only_with_salary", "true");
  if (s.search_period) p.append("search_period", String(s.search_period | 0));
  p.append("order_by", "publication_time");
  p.append("per_page", "100");
  const out = [];
  let found = null;
  for (let page = 0; page < 20 && out.length < maxResults; page++) {
    const params = new URLSearchParams(p);
    params.append("page", String(page));
    let data;
    try {
      data = await getJson(`${OFFICIAL_URL}?${params}`, {
        "User-Agent": userAgent,
        Authorization: `Bearer ${token}`,
        Accept: "application/json"
      });
    } catch (e) {
      console.log("[hh] official error:", e.message);
      break;
    }
    found = data.found ?? found;
    for (const raw of data.items || []) {
      out.push(normalizeOfficial(raw));
      if (out.length >= maxResults) break;
    }
    if (page >= (data.pages || 1) - 1) break;
    await sleep(400);
  }
  return { items: out, total: found };
}
async function search(s, maxResults = 50) {
  const token = process.env.HH_ACCESS_TOKEN || "";
  if (token) {
    const ua = process.env.HH_USER_AGENT || "hh-vacancy-dashboard/1.0 (admin@yourdomain.ru)";
    return searchOfficial(s, token, ua, maxResults);
  }
  return searchShards(s, maxResults);
}

// netlify/functions/debug-run.mjs
async function handler() {
  try {
    const r = await search(
      { text: "\u0432\u0440\u0430\u0447 \u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442", area: [113], max_results: 5 },
      5
    );
    return {
      statusCode: 200,
      body: JSON.stringify({
        ok: true,
        total: r.total,
        got: r.items.length,
        sample: r.items[0]?.name || null
      })
    };
  } catch (e) {
    return { statusCode: 200, body: JSON.stringify({ ok: false, error: e.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
